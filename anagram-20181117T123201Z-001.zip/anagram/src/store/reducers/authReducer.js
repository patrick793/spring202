const initState = {}

const authReducer = (state = initState, action) => {
    return state
}

export default authReducer